from django.apps import AppConfig


class NumberoracleConfig(AppConfig):
    name = 'numberOracle'
